package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.exception.PurchaseException;

public class PurchaseDAOImpl implements PurchaseDAO {
	
	EntityManager manager;
	public PurchaseDAOImpl() throws PurchaseException{
		EntityManagerFactory emf = 
		Persistence.createEntityManagerFactory("JPA-PU");
		manager = emf.createEntityManager();
	
	}
		

	@Override
	public int addPurchaseDetails(PurchaseDetails pr) throws PurchaseException {
		
		// TODO Auto-generated method stu
		
		//inserting record into the database
		manager.getTransaction().begin();
		manager.persist(pr);
		manager.getTransaction().commit();
		//manager.persist(pr); //inserts record in persistence table
		//manager.flush();
		return pr.getPurchaseId();
		
	}

	@Override
	public List<Mobile> getMobileList() {
		
		// TODO Auto-generated method stub
		List<Mobile> list = new ArrayList<>();
		
		TypedQuery<Mobile> qry = manager.createQuery("select p from Mobile p",Mobile.class);
		list =  qry.getResultList();
       
		return list;
		//return 0;
	}

	@Override
	public List<Mobile> getMobileList(int min, int max) {
		// TODO Auto-generated method stub
		TypedQuery<Mobile> qry = manager.createQuery("select p from Mobile p "+" where p.price between :lower and :upper",Mobile.class);
        qry.setParameter("lower", min);
        qry.setParameter("upper", max);
        
        List<Mobile> list = qry.getResultList();
        return list;
	
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		// TODO Auto-generated method stub
		
		manager.getTransaction().begin();
		Mobile mobile = manager.find(Mobile.class, mob.getMobileId());
		mobile.setPrice(mob.getPrice());
		mobile.setQuantity(mob.getQuantity());
		manager.merge(mob);
		manager.getTransaction().commit();
		
		
		return mob;
	}

}
