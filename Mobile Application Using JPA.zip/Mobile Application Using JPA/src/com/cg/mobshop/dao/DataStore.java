package com.cg.mobshop.dao;

public class DataStore {

}
