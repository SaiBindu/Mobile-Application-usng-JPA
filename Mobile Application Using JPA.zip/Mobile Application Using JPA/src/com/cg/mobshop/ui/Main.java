package com.cg.mobshop.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.exception.PurchaseException;
import com.cg.mobshop.service.PurchaseService;
import com.cg.mobshop.service.PurchaseServiceImpl;


public class Main {
	
	public static void main(String args[]) throws PurchaseException {
		
		
		int ch = 0;
		PurchaseService service = new PurchaseServiceImpl();
		
		Scanner sc =  new Scanner(System.in);
		do {
		System.out.println("1. Add purchase details");
		System.out.println("2. Display Mobile Details");
		System.out.println("3. get mobiles within the range");
	    System.out.println("4. Update mobile details");
		System.out.println("5.Exit");
		System.out.println("Enter your choice ");
		ch = sc.nextInt();
		switch(ch) {
		
		case 1:
			System.out.println("Enter custname:");
			String custName = sc.next();
			
			System.out.println("Enter mail id:");
			String mailid = sc.next();
			
			System.out.println("Enter phone no:");
			String phoneNo = sc.next();
			
			System.out.println("Enter mobileid:");
			int mobileId = sc.nextInt();
			
			
			// ADDING PURCHASE DETAILS
			
			
			PurchaseDetails purchase = new PurchaseDetails();
			
			purchase.setCustName(custName);
			purchase.setMailId(mailid);
			//purchase.setMobileId(mobileId);
			purchase.setPhoneNo(phoneNo);
			//purchase.setPurchaseDate(purchaseDate);
			purchase.setMobileId(mobileId);
			
			
			int purchaseid = service.addPurchaseDetails(purchase);
			System.out.println("student record added .."+ purchaseid);
			
		break;
			
			//GETTING MOBILE LIST DETAILS
		case 2:
			List<Mobile> list = service.getMobileList();
			if(list.size() == 0) {
				System.err.println("No record found");
			}
			else{
				for(Mobile mob : list) {
					System.out.println(mob.getMobileId()+ " ");
					System.out.println(mob.getName()+" ");
					System.out.println(mob.getPrice()+" ");
					System.out.println(mob.getQuantity()+" ");
				}
			}
			break;
			
		case 3:
			int mn;
			int mx;
			System.out.println("Enter the min range of mobiles");
			mn = sc.nextInt();
			System.out.println("Enter the max range of mobiles");
			mx = sc.nextInt();
			List<Mobile> list1 = service.getMobileList(mn,mx);
			if(list1.size() == 0) {
				System.err.println("No record found");
			}
			else{
				for(Mobile mob : list1) {
					System.out.println(mob.getMobileId()+ " ");
					System.out.println(mob.getName()+" ");
					System.out.println(mob.getPrice()+" ");
					System.out.println(mob.getQuantity()+" ");
				}
			}
			break;
			
		case 4:
			System.out.println("Enetr mobile id");
			int mobileid = sc.nextInt();
			System.out.println("Enter the price");
			int price  = sc.nextInt();
			System.out.println("Enter th Quantity");
			int quantity = sc.nextInt();
			Mobile mob = new Mobile();
			mob.setMobileId(mobileid);
			mob.setPrice(price);
			//purchase.setMobileId(mobileId);
			mob.setQuantity(quantity);
			try {
				mob = service.updateMobileDetails(mob);
			} catch (PurchaseException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			if(mob == null)
				System.out.println("Record not updated");
			else
				
			    System.out.println("Record updated");
			
	}
		}while(ch != 5);
	}
}