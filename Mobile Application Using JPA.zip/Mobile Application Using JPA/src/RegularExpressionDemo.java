import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class RegularExpressionDemo {
   public static void main(String args[]) {
	   Scanner sc = new Scanner(System.in);
	   Pattern pattern = Pattern.compile("[0-9]{3}"); //{ } specifies width of digits
	   
	   
	   
   
   }
}
